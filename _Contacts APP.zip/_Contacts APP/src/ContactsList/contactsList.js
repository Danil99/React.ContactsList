const contacts = [
	{
		id: 1,
		name: 'Danil',
		phoneNumber: '+380508101005',
		image: 'https://pp.userapi.com/c836121/v836121463/20f03/A-e_URiK05Q.jpg'
	},
	{
		id: 2,
		name: 'Max',
		phoneNumber: '+380958825387',
		image: 'https://pp.userapi.com/c604723/v604723453/7842/JcXxtUfbogg.jpg'
	},
	{
		id: 3,
		name: 'Nastya',
		phoneNumber: '+380665906277',
		image: 'https://pp.userapi.com/c837327/v837327985/21a2c/xMZSemMEF2Y.jpg'
	}
];

export default contacts;
